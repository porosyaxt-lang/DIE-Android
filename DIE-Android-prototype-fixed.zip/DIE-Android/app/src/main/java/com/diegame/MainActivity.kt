package com.diegame

import android.app.Activity
import android.os.Bundle
import android.view.MotionEvent
import android.content.Context
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE); setContentView(GameView(this)) }
}

private class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var heroX = 280f; private var heroY = 0f; private var vy = 0f
    private var move = 0f; private var grounded = false; private var hp = 100f; private var hunger = 78f; private var thirst = 64f; private var rad = 18f
    private var ammo = 12; private var scrap = 0; private var food = 2; private var med = 1
    private var enemyX = 760f; private var enemyHp = 3; private var hitFlash = 0f; private var time = 0f
    private var last = System.nanoTime(); private var message = "Найди припасы и проверь вышку"
    private val worldW = 1800f
    override fun onDraw(c: Canvas) {
        super.onDraw(c); val dt = min(0.04f, (System.nanoTime()-last)/1e9f).toFloat(); last=System.nanoTime(); time+=dt
        val w=width.toFloat(); val h=height.toFloat(); val ground=h*0.79f
        hunger=max(0f,hunger-dt*0.035f); thirst=max(0f,thirst-dt*0.05f)
        if(hunger<=0 || thirst<=0) hp=max(0f,hp-dt*0.35f)
        if(move!=0f) heroX=(heroX+move*260f*dt).coerceIn(55f,worldW-80f)
        if(!grounded){ vy+=1250f*dt; heroY+=vy*dt; if(heroY>=0){heroY=0f;vy=0f;grounded=true} }
        if(enemyHp>0 && kotlin.math.abs(enemyX-heroX)<430f) enemyX += if(enemyX>heroX) -24f*dt else 24f*dt
        if(hitFlash>0)hitFlash-=dt
        val cam=(heroX-w*0.38f).coerceIn(0f,worldW-w)
        // sky
        c.drawColor(Color.rgb(52,25,75)); p.shader=null
        p.color=Color.rgb(220,91,173); c.drawCircle(w*0.79f,h*0.20f, h*0.13f,p)
        p.color=Color.rgb(91,48,112); c.drawRect(0f,h*0.42f,w,ground,p)
        // distant industrial silhouettes
        for(i in 0..6){ val x=((i*310f-cam*0.35f)%(w+350f)+w+350f)%(w+350f)-100f; p.color=Color.rgb(48,39,73); c.drawRect(x,ground-210-(i%3)*45f,x+95,ground,p); p.color=Color.rgb(255,80,191); c.drawRect(x+20,ground-160-(i%3)*45f,x+34,ground-145-(i%3)*45f,p) }
        // factory tower
        p.color=Color.rgb(65,53,76); c.drawRect(w*0.68f,ground-260,w*0.79f,ground,p); p.color=Color.rgb(255,118,190); c.drawRect(w*0.70f,ground-220,w*0.72f,ground-205,p)
        // ground
        p.color=Color.rgb(75,54,70); c.drawRect(0f,ground,w,h,p); p.color=Color.rgb(238,111,174); c.drawRect(0f,ground,w,ground+5,p)
        for(i in 0..22){ val x=((i*97f-cam)%(w+100f)+w+100f)%(w+100f)-30f; p.color=Color.rgb(40,33,52); c.drawCircle(x,ground+25+(i%4)*14f,3f,p) }
        // crates
        drawCrate(c, 540f-cam,ground-48f,Color.rgb(206,133,42)); drawCrate(c, 1160f-cam,ground-45f,Color.rgb(105,83,111))
        // radioactive barrel
        val bx=930f-cam; p.color=Color.rgb(125,54,76); c.drawRoundRect(bx,ground-64,bx+54,ground,9f,9f,p); p.color=Color.YELLOW; c.drawCircle(bx+27,ground-34,13f,p); p.color=Color.BLACK; p.textSize=19f; c.drawText("☢",bx+15,ground-27,p)
        // enemy
        if(enemyHp>0){ val ex=enemyX-cam; p.color=Color.rgb(73,153,91); c.drawRoundRect(ex-17,ground-55,ex+17,ground,12f,12f,p); p.color=Color.BLACK; c.drawCircle(ex-7,ground-39,3f,p); c.drawCircle(ex+7,ground-39,3f,p) }
        // hero shadow + character
        val hx=heroX-cam; val hy=ground-heroY
        p.color=Color.argb(80,0,0,0); c.drawOval(hx-25,ground-7,hx+25,ground+5,p)
        p.color=Color.rgb(255,174,65); c.drawCircle(hx,hy-70,19f,p); p.color=Color.rgb(255,209,112); c.drawCircle(hx+2,hy-72,15f,p); p.color=Color.rgb(238,76,161); c.drawRoundRect(hx-18,hy-51,hx+18,hy-12,9f,9f,p); p.color=Color.rgb(255,190,72); c.drawOval(hx-22,hy-92,hx+15,hy-78,p); p.color=Color.rgb(100,55,45); c.drawLine(hx-10,hy-12,hx-16,hy, p); c.drawLine(hx+10,hy-12,hx+16,hy,p)
        // HUD panels
        panel(c,14f,14f,250f,143f); text(c,"D.I.E.   УР. 1",28f,42f,22f,Color.WHITE); bar(c,28f,58f,210f,9f,100f,100f,Color.rgb(238,55,157)); text(c,"ЗДОРОВЬЕ  ${hp.toInt()}/100",28f,88f,15f,Color.WHITE); bar(c,28f,98f,210f,8f,hunger,100f,Color.rgb(255,166,45)); text(c,"ГОЛОД  ${hunger.toInt()}",28f,125f,14f,Color.WHITE); bar(c,140f,132f,98f,7f,thirst,100f,Color.CYAN)
        panel(c,w-225f,14f,w-14f,84f); text(c,"ДЕНЬ 1  •  ${((time.toInt()/60)%24).toString().padStart(2,'0')}:${(time.toInt()%60).toString().padStart(2,'0')}",w-210f,45f,17f,Color.WHITE); text(c,"☢  РАДИАЦИЯ ${rad.toInt()}",w-210f,73f,14f,Color.YELLOW)
        panel(c,w*0.35f,h-62f,w*0.65f,h-14f); text(c,message,w*0.35f+12f,h-32f,14f,Color.WHITE)
        // touch controls
        button(c,70f,h-92f,"◀"); button(c,158f,h-92f,"▶"); button(c,w-175f,h-92f,"ПРЫЖОК"); button(c,w-75f,h-92f,"УДАР")
        // small inventory
        text(c,"🔫 $ammo     🧰 $scrap     🥫 $food     ✚ $med",w*0.36f, h-83f,15f,Color.WHITE)
        postInvalidateOnAnimation()
    }
    private fun drawCrate(c:Canvas,x:Float,y:Float,col:Int){p.color=col;c.drawRoundRect(x,y,x+58,y+48,5f,5f,p);p.color=Color.rgb(65,43,60);p.strokeWidth=5f;c.drawLine(x+5,y+10,x+53,y+10,p);c.drawLine(x+29,y+2,x+29,y+46,p)}
    private fun panel(c:Canvas,l:Float,t:Float,r:Float,b:Float){p.color=Color.argb(220,30,12,43);c.drawRoundRect(l,t,r,b,14f,14f,p);p.color=Color.rgb(244,74,184);p.style=Paint.Style.STROKE;p.strokeWidth=2f;c.drawRoundRect(l,t,r,b,14f,14f,p);p.style=Paint.Style.FILL}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,col:Int){p.color=col;p.textSize=size;p.typeface=Typeface.create("sans-serif-condensed",Typeface.BOLD);c.drawText(s,x,y,p)}
    private fun bar(c:Canvas,x:Float,y:Float,w:Float,h:Float,v:Float,maxv:Float,col:Int){p.color=Color.DKGRAY;c.drawRoundRect(x,y,x+w,y+h,h,h,p);p.color=col;c.drawRoundRect(x,y,x+w*(v/maxv).coerceIn(0f,1f),y+h,h,h,p)}
    private fun button(c:Canvas,x:Float,y:Float,label:String){p.color=Color.argb(210,46,14,58);c.drawRoundRect(x-34,y-28,x+34,y+28,13f,13f,p);p.color=Color.rgb(255,88,195);p.style=Paint.Style.STROKE;p.strokeWidth=2f;c.drawRoundRect(x-34,y-28,x+34,y+28,13f,13f,p);p.style=Paint.Style.FILL;text(c,label,x- p.measureText(label)/2,y+7,if(label.length>2)12f else 24f,Color.WHITE)}
    override fun onTouchEvent(e:MotionEvent):Boolean{ val x=e.x;val y=e.y;val h=height.toFloat(); val w=width.toFloat(); when(e.action){MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE->{move=0f;if(y>h-135&&x<220){move=if(x<115)-1f else 1f};if(e.action==MotionEvent.ACTION_DOWN&&y>h-135){if(x in 115f..205f){ } else if(x>w-225&&x<w-110){if(grounded){vy=-560f;grounded=false}} else if(x>w-110){if(ammo>0){ammo--;if(kotlin.math.abs(enemyX-heroX)<360f){enemyHp--;message=if(enemyHp<=0)"Противник устранён!" else "Попадание!"}else message="Выстрел в пустоту"}}}; if(e.action==MotionEvent.ACTION_DOWN&&x in 470f..640f&&kotlin.math.abs(heroX-540f)<100f){scrap+=2;food++;message="Найдено: лом и консервы";heroX+=8f};if(e.action==MotionEvent.ACTION_DOWN&&x>w*0.78f&&y<h*0.25f){rad=max(0f,rad-1f)} };MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{move=0f}};return true}
}
